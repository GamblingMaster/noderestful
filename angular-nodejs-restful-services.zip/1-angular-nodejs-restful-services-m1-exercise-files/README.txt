Source code for the application shown in this course can be found at:

https://github.com/DanWahlin/Angular-NodeJS-MongoDB-CustomersService

After downloading the .zip or cloning the project you'll find the final source code for the sample application in the "src" folder.

If you'd like to follow along in the different course modules, open the "modules" folder and follow the steps shown in the README file to get it up and running.